<!DOCTYPE html>
<html>
<head>
<title> User Agent Check </title>
<style>
.boxed{
        margin:10px 10px 10px 10px;
        position: absolute;
        top: 45%;
        left: 25%;
        transform: translateY(-50%);
        background: grey;
        border: 1px solid white ;
}
.inner{
        margin:10px 10px 10px 10px;
        color: black;
        text-align: center;
}

</style>
<head>
<body bgcolor="black">

<div class="boxed">
	<div class="inner">

	<?php
		$ua=$_SERVER['HTTP_USER_AGENT'];
		echo $ua;
		echo "<br>";
		if($ua=="Python-urllib/2.7"){
			echo '<br>BOT DETECTED ';
		}
		else{
			echo '<br>Since you are not a bot, here is the secret code : 31nfd8oufon#!f <br>';
		}

	?>

</div>
</div>
</body>
</html>
