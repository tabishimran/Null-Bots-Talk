<html>
<head>
<title> Admin Panel </title>
<style>
.boxed{
        margin:10px 10px 10px 10px;
        position: absolute;
        top: 50%;
        left: 30%;
        transform: translateY(-50%);
        background: grey;
        border: 1px solid white ;
}
.inner{
        margin:10px 10px 10px 10px;
        color: black;
        text-align: center;
}
</style>
</head>
<body bgcolor="black">
<center>
<font color="white">
<div class="boxed">
	<div class="inner">
		<div id="result"
		<?php
			if($_POST['name']=="admin" && $_POST['password']=="10012"){
				echo "<h1> LOGIN SUCCESSFUL </h1><br><br>";
				echo "<h1> Welcome Admin    </h1>";
				echo '<img src="snape.gif">';
			}
			else{
				echo "<h1> LOGIN FAILED    </h1>";
			}
		?>
		</div>
	</div>
</div>
</font>
</center>
</body>
</html>
