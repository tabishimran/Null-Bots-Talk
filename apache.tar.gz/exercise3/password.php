<html>
<head>
<title> Secret Codes </title>
<style>
.boxed{
        margin:10px 10px 10px 10px;
        position: absolute;
        top: 50%;
        left: 37%;
        transform: translateY(-50%);
        background: grey;
        border: 1px solid white ;
}
.inner{
        margin:10px 10px 10px 10px;
        color: black;
        text-align: center;
}
</style>
<head>

<body bgcolor="black">
<center>
<div class="boxed">
	Welcome                 : <?php echo $_POST["name"]; ?><br><br>
	Your email address is   : <?php echo $_POST["email"]; ?><br><br>
	<div class="inner">
		Your secret code is     :
			<div id="password">
			 <?php echo base64_encode($_POST["name"]); ?>
			</div>
	</div>
</div>
</center>
</body>
</html> 
